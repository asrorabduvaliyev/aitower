import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() => runApp(const TourismApp());

class TourismApp extends StatelessWidget {
  const TourismApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'AI Smart Tourism',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorSchemeSeed: const Color(0xFF0D3B66), useMaterial3: true),
        home: const HomeScreen(),
      );
}
