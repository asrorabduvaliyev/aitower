import 'package:latlong2/latlong.dart';

class Stop {
  final String name;
  final double travelKm, costUsd;
  final int visitMinutes, travelMinutes;
  Stop.fromJson(Map<String, dynamic> j)
      : name = j['name'],
        travelKm = (j['travel_km'] as num).toDouble(),
        costUsd = (j['cost_usd'] as num).toDouble(),
        visitMinutes = j['visit_minutes'],
        travelMinutes = (j['travel_minutes'] as num).round();
}

class DayPlan {
  final int day, minutes;
  final double distanceKm, costUsd;
  final List<Stop> stops;
  final List<LatLng> path;
  DayPlan.fromJson(Map<String, dynamic> j)
      : day = j['day'],
        minutes = (j['minutes'] as num).round(),
        distanceKm = (j['distance_km'] as num).toDouble(),
        costUsd = (j['cost_usd'] as num).toDouble(),
        stops = (j['stops'] as List).map((e) => Stop.fromJson(e)).toList(),
        path = (j['path'] as List)
            .map((p) => LatLng((p[0] as num).toDouble(), (p[1] as num).toDouble()))
            .toList();
}

class RoutePlan {
  final List<DayPlan> days;
  final double totalKm, totalCost;
  RoutePlan.fromJson(Map<String, dynamic> j)
      : days = (j['days'] as List).map((e) => DayPlan.fromJson(e)).toList(),
        totalKm = (j['total_distance_km'] as num).toDouble(),
        totalCost = (j['total_cost_usd'] as num).toDouble();
}
