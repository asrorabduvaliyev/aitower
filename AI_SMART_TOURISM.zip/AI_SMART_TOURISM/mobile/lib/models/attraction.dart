class Attraction {
  final int id;
  final String name, city, category, tags, description;
  final double lat, lon, rating, costUsd, score;
  final int visitMinutes;

  Attraction.fromJson(Map<String, dynamic> j)
      : id = j['id'],
        name = j['name'],
        city = j['city'],
        category = j['category'],
        tags = j['tags'] ?? '',
        description = j['description'] ?? '',
        lat = (j['lat'] as num).toDouble(),
        lon = (j['lon'] as num).toDouble(),
        rating = (j['rating'] as num).toDouble(),
        costUsd = (j['cost_usd'] as num).toDouble(),
        score = ((j['score'] ?? 0) as num).toDouble(),
        visitMinutes = j['visit_minutes'];
}
