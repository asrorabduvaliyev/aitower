import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import '../models/route_plan.dart';
import '../services/api_service.dart';

class RouteScreen extends StatefulWidget {
  final List<int> ids;
  final double? lat, lon;
  const RouteScreen({super.key, required this.ids, this.lat, this.lon});
  @override
  State<RouteScreen> createState() => _RouteScreenState();
}

class _RouteScreenState extends State<RouteScreen> {
  late Future<RoutePlan> future =
      ApiService().planRoute(widget.ids, lat: widget.lat, lon: widget.lon);
  int day = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Optimal marshrut')),
      body: FutureBuilder<RoutePlan>(
        future: future,
        builder: (c, s) {
          if (s.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
          if (s.hasError) return Center(child: Text('Xato: ${s.error}'));
          final plan = s.data!;
          final d = plan.days[day];
          return Column(children: [
            Padding(
              padding: const EdgeInsets.all(8),
              child: Text('Jami: ${plan.totalKm} km • \$${plan.totalCost.toStringAsFixed(0)}'),
            ),
            Wrap(spacing: 8, children: [
              for (var i = 0; i < plan.days.length; i++)
                ChoiceChip(label: Text('${i + 1}-kun'), selected: day == i, onSelected: (_) => setState(() => day = i)),
            ]),
            SizedBox(
              height: 260,
              child: FlutterMap(
                key: ValueKey(day),
                options: MapOptions(initialCameraFit: CameraFit.coordinates(
                    coordinates: d.path, padding: const EdgeInsets.all(40), maxZoom: 15)),
                children: [
                  TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'uz.tourism.app'),
                  PolylineLayer(polylines: [Polyline(points: d.path, strokeWidth: 4, color: Colors.teal)]),
                  MarkerLayer(markers: [for (final p in d.path.toSet()) Marker(point: p, child: const Icon(Icons.place, color: Colors.deepOrange))]),
                ],
              ),
            ),
            Expanded(child: ListView(children: [
              for (var i = 0; i < d.stops.length; i++)
                ListTile(
                  leading: CircleAvatar(child: Text('${i + 1}')),
                  title: Text(d.stops[i].name),
                  subtitle: Text('${d.stops[i].visitMinutes} daq'
                      '${d.stops[i].travelKm > 0 ? ' • yo\'l: ${d.stops[i].travelKm} km, ${d.stops[i].travelMinutes} daq' : ''}'),
                ),
            ])),
          ]);
        },
      ),
    );
  }
}
