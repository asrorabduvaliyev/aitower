import 'package:flutter/material.dart';
import '../models/attraction.dart';
import '../services/api_service.dart';
import '../widgets/attraction_card.dart';
import 'route_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  static const tags = {'tarix': 'Tarix', 'foto': 'Foto', 'taom': 'Taom', 'bozor': 'Bozor', 'hunar': 'Hunarmandchilik', 'tabiat': 'Tabiat'};
  final api = ApiService();
  final interests = <String>{'tarix'};
  final selected = <int>{};
  List<Attraction> items = [];
  bool loading = false;
  String? error;
  double? lat, lon;

  Future<void> load() async {
    setState(() { loading = true; error = null; });
    try {
      final pos = await api.currentPosition();
      lat = pos?.latitude; lon = pos?.longitude;
      items = await api.recommend(interests.toList(), lat: lat, lon: lon);
    } catch (e) {
      error = 'Serverga ulanib bo\'lmadi. Backend ishlayotganini tekshiring.';
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  void initState() { super.initState(); load(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AI Smart Tourism')),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Wrap(spacing: 8, children: tags.entries.map((e) => FilterChip(
            label: Text(e.value),
            selected: interests.contains(e.key),
            onSelected: (v) { setState(() => v ? interests.add(e.key) : interests.remove(e.key)); load(); },
          )).toList()),
        ),
        Expanded(child: loading
            ? const Center(child: CircularProgressIndicator())
            : error != null
                ? Center(child: Text(error!))
                : ListView(children: items.map((a) => AttractionCard(
                    a: a, selected: selected.contains(a.id),
                    onTap: () => setState(() => selected.contains(a.id) ? selected.remove(a.id) : selected.add(a.id)),
                  )).toList())),
      ]),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: selected.isEmpty ? null : () => Navigator.push(context, MaterialPageRoute(
            builder: (_) => RouteScreen(ids: selected.toList(), lat: lat, lon: lon))),
        icon: const Icon(Icons.route),
        label: Text('Marshrut (${selected.length})'),
      ),
    );
  }
}
