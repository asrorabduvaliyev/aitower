import 'package:flutter/material.dart';
import '../models/attraction.dart';

class AttractionCard extends StatelessWidget {
  final Attraction a;
  final bool selected;
  final VoidCallback onTap;
  const AttractionCard({super.key, required this.a, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        onTap: onTap,
        title: Text(a.name, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text('${a.city} • ★ ${a.rating} • ${a.visitMinutes} daq • \$${a.costUsd.toStringAsFixed(0)}\n${a.description}'),
        isThreeLine: true,
        trailing: Icon(selected ? Icons.check_circle : Icons.add_circle_outline,
            color: selected ? Colors.teal : null),
      ),
    );
  }
}
