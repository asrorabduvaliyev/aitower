import 'dart:convert';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import '../models/attraction.dart';
import '../models/route_plan.dart';

class ApiService {
  // Android emulyator uchun 10.0.2.2, haqiqiy telefon uchun kompyuter IP manzili.
  static const String baseUrl = String.fromEnvironment('API_URL', defaultValue: 'http://10.0.2.2:8000');
  static const _h = {'Content-Type': 'application/json'};

  Future<Position?> currentPosition() async {
    try {
      var p = await Geolocator.checkPermission();
      if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
      if (p == LocationPermission.denied || p == LocationPermission.deniedForever) return null;
      return await Geolocator.getCurrentPosition();
    } catch (_) {
      return null;
    }
  }

  Future<List<Attraction>> recommend(List<String> interests, {double? lat, double? lon}) async {
    final r = await http.post(Uri.parse('$baseUrl/recommendations'),
        headers: _h, body: jsonEncode({'interests': interests, 'lat': lat, 'lon': lon, 'limit': 12}));
    if (r.statusCode != 200) throw Exception('Server xatosi: ${r.statusCode}');
    return (jsonDecode(utf8.decode(r.bodyBytes)) as List).map((e) => Attraction.fromJson(e)).toList();
  }

  Future<RoutePlan> planRoute(List<int> ids, {double? lat, double? lon}) async {
    final r = await http.post(Uri.parse('$baseUrl/routes/plan'),
        headers: _h, body: jsonEncode({'attraction_ids': ids, 'start_lat': lat, 'start_lon': lon}));
    if (r.statusCode != 200) throw Exception('Server xatosi: ${r.statusCode}');
    return RoutePlan.fromJson(jsonDecode(utf8.decode(r.bodyBytes)));
  }
}
