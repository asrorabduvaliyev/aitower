# AI Smart Tourism

## Backend (Docker)
    docker compose up --build        # API: http://localhost:8000/docs

## Backend (Docker'siz)
    cd backend && pip install -r requirements.txt
    uvicorn app.main:app --reload    # SQLite ishlatiladi

## Mobil ilova va APK
    cd mobile
    flutter create . --org uz.tourism --project-name ai_smart_tourism
    flutter pub get
    # android/app/src/main/AndroidManifest.xml ga <manifest> ichiga qo'shing:
    #   <uses-permission android:name="android.permission.INTERNET"/>
    #   <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
    #   va <application> tegiga: android:usesCleartextTraffic="true"  (faqat test uchun, http)
    flutter run --dart-define=API_URL=http://<KOMPYUTER_IP>:8000
    flutter build apk --release --dart-define=API_URL=http://<KOMPYUTER_IP>:8000
    # APK: build/app/outputs/flutter-apk/app-release.apk
